import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  queans=[{
    que:"1.Two Very Different Australias?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },
  {
    que:"2.What Does Darwin Mean to You?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },{
    que:"3.Where Totem Poles Are a Living Art ?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },{
    que:"1.Two Very Different Australias?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },
  {
    que:"2.What Does Darwin Mean to You?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },{
    que:"3.Where Totem Poles Are a Living Art ?",
    ans:"A Google Docs scam that appears to be widespread began landing in users’ inboxes on Wednesday in what seemed to be a sophisticated phishing."
  },]
  constructor() { }

  ngOnInit(): void {
  }

}
