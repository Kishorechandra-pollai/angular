import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testmonial',
  templateUrl: './testmonial.component.html',
  styleUrls: ['./testmonial.component.css']
})
export class TestmonialComponent implements OnInit {
  testdetails=[{
    para:"“The recording starts with the patter of a summer squall. Later a drifting tone like that of a not-quite-tuned-in radio station rises and for a while drowns out the patter. These are the sounds encountered by NASA.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.”",
    img:"https://preview.colorlib.com/theme/educrown/assest/img/testmonial/xtestmonial.jpg.pagespeed.ic.OFebNhqTb1.webp",
    name:"Harold Crouse",
    post:"Sales manager"
  },{
    para:"“The recording starts with the patter of a summer squall. Later a drifting tone like that of a not-quite-tuned-in radio station rises and for a while drowns out the patter. These are the sounds encountered by NASA.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.”",
    img:"https://preview.colorlib.com/theme/educrown/assest/img/testmonial/xtestmonial.jpg.pagespeed.ic.OFebNhqTb1.webp",
    name:"Harold Crouse",
    post:"Sales manager"
  },{
    para:"“The recording starts with the patter of a summer squall. Later a drifting tone like that of a not-quite-tuned-in radio station rises and for a while drowns out the patter. These are the sounds encountered by NASA.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.”",
    img:"https://preview.colorlib.com/theme/educrown/assest/img/testmonial/xtestmonial.jpg.pagespeed.ic.OFebNhqTb1.webp",
    name:"Harold Crouse",
    post:"Sales manager"
  }]
  constructor() { }

  ngOnInit(): void {
  }

}
