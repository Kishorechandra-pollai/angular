import { Component, EventEmitter, OnInit, Output, Pipe } from '@angular/core';
import '@angular/localize/init';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
// @Pipe({ name:'appFilter' })
// export class FilterPipe implements PipeTransform{
//   transf
// }
export class SliderComponent implements OnInit {
  slides: any[] = new Array(3).fill({id: -1, src: '', title: '', subtitle: ''});
  search="";
  characters=[
    'Ant-man',
    'Aquaman',
    'Avengers',
  ]
  // @Output() ch = new EventEmitter<string>();
  ch:string[]=[];
  ca=[];
  images=['https://images.unsplash.com/photo-1663776211814-ffdd8553e00d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80','https://images.unsplash.com/photo-1663776211814-ffdd8553e00d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80','https://images.unsplash.com/photo-1663776211814-ffdd8553e00d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80'];
  constructor() { }
  show(name: string){
      console.log(name)
      if(this.characters.indexOf(name)!=-1){
        this.ch.push(name);
      }
      console.log(this.ch);
  }
  ngOnInit(): void {
  }

}
