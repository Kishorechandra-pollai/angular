import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  blogCard=[{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/blog/xblog-1.jpg.pagespeed.ic._6_ysfH-HB.webp",
    para:"Blazeon Scrambles to Police Content Amid Rapid Growth",
    date:"Feb 01, 2016",
    name:"Mark Stonis"
  },{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/blog/xblog-2.jpg.pagespeed.ic.uqw-c8w169.webp",
    para:"Blazeon Scrambles to Police Content Amid Rapid Growth",
    date:"Feb 01, 2016",
    name:"Mark Stonis"
  },{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/blog/xblog-3.jpg.pagespeed.ic.laDBt7eSYq.webp",
    para:"Blazeon Scrambles to Police Content Amid Rapid Growth",
    date:"Feb 01, 2016",
    name:"Mark Stonis"
  }]
  constructor() { }

  ngOnInit(): void {
  }

}
