import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  cardDetails=[{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/course/xblog-4.jpg.pagespeed.ic.vZMvrWmWGr.webp",
    intro:"Introduction to Resume Writing",
    para:"MPs who are leaving the protection of for the campaign trail will render...",
    link:"Enroll the Courses",
    cost:"$29.99",
  },{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/course/xblog-1.jpg.pagespeed.ic.owtLtlBSrK.webp",
    intro:"Introduction to Resume Writing",
    para:"MPs who are leaving the protection of for the campaign trail will render...",
    link:"Enroll the Courses",
    cost:"$29.99",
  },{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/course/xblog-2.jpg.pagespeed.ic.gAR-nm1uIC.webp",
    intro:"Introduction to Resume Writing",
    para:"MPs who are leaving the protection of for the campaign trail will render...",
    link:"Enroll the Courses",
    cost:"$29.99",
  },{
    img:"https://preview.colorlib.com/theme/educrown/assest/img/course/xblog-3.jpg.pagespeed.ic.iw7y8wUP_P.webp",
    intro:"Introduction to Resume Writing",
    para:"MPs who are leaving the protection of for the campaign trail will render...",
    link:"Enroll the Courses",
    cost:"$29.99",
  }]

  constructor() { }

  ngOnInit(): void {
  }

}
